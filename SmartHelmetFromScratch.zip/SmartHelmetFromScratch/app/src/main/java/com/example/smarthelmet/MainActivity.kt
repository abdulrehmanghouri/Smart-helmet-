package com.example.smarthelmet

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.CountDownTimer
import android.telephony.SmsManager
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("smart_helmet_prefs", Context.MODE_PRIVATE) }
    private val contacts = mutableListOf<String>()
    private lateinit var contactText: TextView
    private lateinit var statusText: TextView
    private lateinit var historyText: TextView
    private var countdown: CountDownTimer? = null
    private var pendingDialog: AlertDialog? = null
    private var locationForAlert: Location? = null
    private val permissionRequestCode = 740

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadContacts()
        buildScreen()
        updateContactsView()
        updateHistoryView()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(245, 248, 247))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val header = TextView(this).apply {
            text = "SMART HELMET"
            textSize = 13f
            letterSpacing = 0.16f
            setTextColor(Color.rgb(20, 125, 100))
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(header)

        val title = TextView(this).apply {
            text = "Your ride.\\nYour safety."
            textSize = 31f
            setTextColor(Color.rgb(20, 42, 39))
            setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Emergency support demo • Android"
            textSize = 14f
            setTextColor(Color.rgb(91, 108, 103))
        }
        root.addView(subtitle)

        val statusCard = card()
        statusCard.setPadding(dp(16), dp(16), dp(16), dp(16))
        statusText = TextView(this).apply {
            text = "SYSTEM READY"
            textSize = 17f
            setTextColor(Color.rgb(20, 125, 100))
            setTypeface(null, Typeface.BOLD)
        }
        statusCard.addView(statusText)
        statusCard.addView(label("Accident detection is simulated in this university demo. No helmet sensor is connected."))
        root.addView(statusCard, marginParams(top = 20))

        val sosButton = button("SIMULATE ACCIDENT / START SOS", Color.rgb(183, 48, 48), Color.WHITE)
        sosButton.setOnClickListener { beginSosFlow() }
        root.addView(sosButton, marginParams(top = 14))

        val contactCard = card()
        contactCard.addView(sectionTitle("Emergency contacts"))
        contactCard.addView(label("Add phone numbers that should receive the SOS SMS. Use international format when possible, e.g. +923001234567."))
        contactText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(35, 53, 49))
            setPadding(0, dp(10), 0, dp(10))
        }
        contactCard.addView(contactText)
        val contactButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addButton = button("Add contact", Color.rgb(20, 125, 100), Color.WHITE)
        addButton.setOnClickListener { showAddContactDialog() }
        val removeButton = button("Remove last", Color.rgb(230, 237, 234), Color.rgb(20, 42, 39))
        removeButton.setOnClickListener {
            if (contacts.isNotEmpty()) {
                contacts.removeAt(contacts.lastIndex)
                saveContacts()
                updateContactsView()
            }
        }
        contactButtons.addView(addButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        contactButtons.addView(removeButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
        contactCard.addView(contactButtons)
        root.addView(contactCard, marginParams(top = 18))

        val historyCard = card()
        historyCard.addView(sectionTitle("Recent activity"))
        historyText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(75, 91, 86))
        }
        historyCard.addView(historyText)
        root.addView(historyCard, marginParams(top = 18))

        val note = TextView(this).apply {
            text = "Important: after the 10-second countdown, SMS sending is attempted automatically only if SMS permission is granted and the device supports SMS. Test with consenting contacts only."
            textSize = 12f
            setTextColor(Color.rgb(91, 108, 103))
            setPadding(dp(2), dp(18), dp(2), 0)
        }
        root.addView(note)
    }

    private fun beginSosFlow() {
        if (contacts.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Add an emergency contact")
                .setMessage("Add at least one phone number before testing the SOS flow.")
                .setPositiveButton("Add contact") { _, _ -> showAddContactDialog() }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.SEND_SMS)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
            needed.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.distinct().toTypedArray(), permissionRequestCode)
            Toast.makeText(this, "Grant the requested permissions, then tap SOS again.", Toast.LENGTH_LONG).show()
            return
        }

        locationForAlert = getLastKnownLocation()
        showCountdownDialog()
    }

    private fun showCountdownDialog() {
        val message = buildSosMessage(locationForAlert)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(10), dp(22), dp(4))
        }
        val countdownLabel = TextView(this).apply {
            text = "Sending in 10 seconds unless you tap IGNORE"
            textSize = 16f
            setTextColor(Color.rgb(183, 48, 48))
            setTypeface(null, Typeface.BOLD)
        }
        body.addView(countdownLabel)
        body.addView(TextView(this).apply {
            text = "SOS MESSAGE PREVIEW"
            textSize = 12f
            setTextColor(Color.rgb(20, 125, 100))
            setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(14), 0, dp(6))
        })
        val preview = TextView(this).apply {
            text = message
            textSize = 14f
            setTextColor(Color.rgb(35, 53, 49))
        }
        body.addView(preview)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Possible accident detected")
            .setView(body)
            .setNegativeButton("IGNORE — CANCEL SOS", null)
            .setCancelable(false)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.rgb(183, 48, 48))
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                countdown?.cancel()
                pendingDialog = null
                dialog.dismiss()
                statusText.text = "SOS CANCELLED"
                statusText.setTextColor(Color.rgb(20, 125, 100))
                addHistory("SOS cancelled by user")
            }
        }
        pendingDialog = dialog
        dialog.show()

        countdown = object : CountDownTimer(10_000, 1_000) {
            override fun onTick(millisUntilFinished: Long) {
                countdownLabel.text = "Sending in ${((millisUntilFinished + 999) / 1000)} seconds unless you tap IGNORE"
            }

            override fun onFinish() {
                if (pendingDialog?.isShowing == true) {
                    pendingDialog?.dismiss()
                    pendingDialog = null
                    sendSosSms(buildSosMessage(locationForAlert))
                }
            }
        }.start()
    }

    private fun sendSosSms(message: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            statusText.text = "SMS PERMISSION REQUIRED"
            statusText.setTextColor(Color.rgb(183, 48, 48))
            addHistory("SMS not sent: permission missing")
            AlertDialog.Builder(this)
                .setTitle("SMS permission needed")
                .setMessage("Android has not granted SMS permission. No message was sent. Grant SMS permission in app settings and test again.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        try {
            if (!packageManager.hasSystemFeature("android.hardware.telephony")) {
                throw IllegalStateException("This device does not support telephony SMS.")
            }
            val smsManager = if (android.os.Build.VERSION.SDK_INT >= 31) {
                getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            var sentCount = 0
            val failed = mutableListOf<String>()
            contacts.toList().forEach { number ->
                try {
                    val parts = smsManager.divideMessage(message)
                    smsManager.sendMultipartTextMessage(number, null, parts, null, null)
                    sentCount++
                } catch (e: Exception) {
                    failed.add(number)
                }
            }
            if (sentCount > 0) {
                statusText.text = "SOS SMS SUBMITTED"
                statusText.setTextColor(Color.rgb(20, 125, 100))
                addHistory("SOS SMS submitted to $sentCount contact(s)")
                AlertDialog.Builder(this)
                    .setTitle("SOS message submitted")
                    .setMessage("Android accepted the SMS send request for $sentCount contact(s). This does not guarantee delivery. Check signal, SIM, balance, and carrier service.")
                    .setPositiveButton("OK", null)
                    .show()
            } else {
                statusText.text = "SMS SEND FAILED"
                statusText.setTextColor(Color.rgb(183, 48, 48))
                addHistory("SOS SMS failed")
                AlertDialog.Builder(this)
                    .setTitle("SMS could not be sent")
                    .setMessage("No SMS send request was accepted. Check SIM/service, phone numbers, and permissions.")
                    .setPositiveButton("OK", null)
                    .show()
            }
        } catch (e: Exception) {
            statusText.text = "SMS SEND FAILED"
            statusText.setTextColor(Color.rgb(183, 48, 48))
            addHistory("SMS failed: ${e.message ?: "unknown error"}")
            AlertDialog.Builder(this)
                .setTitle("SMS could not be sent")
                .setMessage("Check that this is a phone with SMS capability, a working SIM, SMS service, and permission. Details: ${e.message ?: "unknown error"}")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun buildSosMessage(location: Location?): String {
        val locationLine = if (location != null) {
            "Location: https://maps.google.com/?q=${location.latitude},${location.longitude}"
        } else {
            "Location: unavailable. Please call the rider for their location."
        }
        return "SOS! Possible motorcycle accident detected by Smart Helmet. The rider may need immediate assistance. $locationLine"
    }

    private fun getLastKnownLocation(): Location? {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = lm.getProviders(true)
            providers.mapNotNull { provider ->
                try { lm.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
            }.maxByOrNull { it.time }
        } catch (_: Exception) {
            null
        }
    }

    private fun showAddContactDialog() {
        val input = EditText(this).apply {
            hint = "+923001234567"
            inputType = InputType.TYPE_CLASS_PHONE
            setSingleLine(true)
        }
        val container = LinearLayout(this).apply {
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        }
        AlertDialog.Builder(this)
            .setTitle("Add emergency phone")
            .setMessage("Enter a phone number that has agreed to receive test alerts.")
            .setView(container)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val number = input.text.toString().trim()
                if (number.length >= 7) {
                    if (!contacts.contains(number)) {
                        contacts.add(number)
                        saveContacts()
                        updateContactsView()
                    }
                } else {
                    Toast.makeText(this, "Enter a valid phone number.", Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    private fun loadContacts() {
        contacts.clear()
        contacts.addAll(prefs.getStringSet("contacts", emptySet())?.toList()?.sorted() ?: emptyList())
    }

    private fun saveContacts() {
        prefs.edit().putStringSet("contacts", contacts.toSet()).apply()
    }

    private fun updateContactsView() {
        contactText.text = if (contacts.isEmpty()) "No contacts added yet." else contacts.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n")
    }

    private fun addHistory(item: String) {
        val timestamp = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date())
        val old = prefs.getString("history", "") ?: ""
        val updated = ("$timestamp — $item\n$old").lines().take(6).joinToString("\n")
        prefs.edit().putString("history", updated).apply()
        updateHistoryView()
    }

    private fun updateHistoryView() {
        val history = prefs.getString("history", "") ?: ""
        historyText.text = if (history.isBlank()) "No activity yet. Use the test button to try the SOS flow." else history
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(Color.WHITE, dp(18))
        elevation = dp(2).toFloat()
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 18f
        setTextColor(Color.rgb(20, 42, 39))
        setTypeface(null, Typeface.BOLD)
        setPadding(0, 0, 0, dp(8))
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.rgb(91, 108, 103))
        setPadding(0, dp(6), 0, dp(4))
    }

    private fun button(text: String, bg: Int, fg: Int) = Button(this).apply {
        this.text = text
        textSize = 12f
        isAllCaps = false
        setTextColor(fg)
        background = rounded(bg, dp(12))
        stateListAnimator = null
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun marginParams(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) {
            val smsGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
            if (smsGranted) {
                Toast.makeText(this, "Permissions checked. Tap SOS again to start the countdown.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "SMS permission is required for automatic SMS sending.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        countdown?.cancel()
        pendingDialog?.dismiss()
        super.onDestroy()
    }
}
