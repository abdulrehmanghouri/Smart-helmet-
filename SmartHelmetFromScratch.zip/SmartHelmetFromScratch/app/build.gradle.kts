plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.smarthelmet"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.smarthelmet"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}


dependencies {
    implementation("androidx.core:core:1.15.0")
}
