# Smart Helmet SOS — Android project from scratch

A small native Android Studio project written in Kotlin. Accident detection is deliberately simulated using the on-screen button. It is not connected to an actual helmet sensor.

## SOS behavior
1. Add one or more emergency phone numbers.
2. Tap **SIMULATE ACCIDENT / START SOS**.
3. The app shows a 10-second countdown and an editable-by-source SOS preview.
4. Tap **IGNORE — CANCEL SOS** before the countdown finishes to cancel.
5. If Ignore is not tapped within 10 seconds, the app attempts to send an SMS to each saved contact using Android's `SmsManager`.
6. The SMS includes a Google Maps link if a last-known device location is available; otherwise it explicitly says location is unavailable.

## Permissions and requirements
- `SEND_SMS`: required for direct SMS sending. Android runtime permission is requested. If denied, automatic SMS cannot be sent.
- `ACCESS_FINE_LOCATION` / `ACCESS_COARSE_LOCATION`: location permissions. The current implementation uses last-known location only; it may be missing or stale.
- A phone with SMS-capable hardware, active SIM, carrier SMS service, and any required account balance/plan is needed.
- SMS submission does not guarantee delivery. This demo does not receive delivery reports.
- The countdown works while the app screen is active. This project is a foreground demo, not a production-grade always-on accident monitoring service. Do not assume it will send reliably if the app is force-stopped, killed, or the device is off.
- For real use, test with consenting contacts only and consult local requirements. SMS permission is restricted by some app stores/policies; direct SMS may be unsuitable for a public Play Store release without meeting policy requirements.

## Open in Android Studio
1. Extract this ZIP.
2. Open the `SmartHelmetFromScratch` folder.
3. Allow Gradle sync and install Android SDK 35 if prompted.
4. Run on an actual Android phone. The emulator generally cannot deliver real SMS.
5. Grant SMS and location permissions when prompted, add a consenting test contact, and test carefully.

## Build notes
This is a source project, not a prebuilt APK. It was generated as source and has not been compiled or device-tested in this environment. Android Studio may suggest a compatible Gradle/Android Gradle Plugin update depending on your installation.


## Build an installable APK in GitHub Actions (no Android Studio required on your computer)
1. Create a new GitHub repository and upload the contents of this project.
2. In the repository, open **Actions** and enable workflows if prompted.
3. Run **Build Smart Helmet APK** using **Run workflow**, or push a commit to `main`.
4. When the workflow finishes, open its run and download the `SmartHelmet-debug-apk` artifact.
5. Extract the artifact on your phone/computer to get `app-debug.apk`. Transfer it to your Android phone and install it. Android may ask you to allow installs from that source.
6. Only test the countdown with consenting contacts. Direct SMS permission may be restricted by device policy or distribution rules.

The cloud workflow is provided as a build route; the APK is not included in this ZIP and the workflow has not been run/verified from this environment.
